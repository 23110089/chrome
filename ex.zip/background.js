const FIXED_URLS = [
  'https://idx.google.com/idx-00-66583824',
  'https://idx.google.com/idx02-35251293',
  'https://idx.google.com/idx03-14363638',
  'https://idx.google.com/idx04-15208805',
  'https://idx.google.com/idx05-86047270',
  'https://idx.google.com/idx06-95381027',
  'https://idx.google.com/vps07-20010284',
  'https://idx.google.com/idx09-22332842',
  'https://idx.google.com/idx10-19483612',
  'https://idx.google.com/idx11-47796700',
  'https://idx.google.com/idx12-73856221',
  'https://idx.google.com/idx13-69440052',
  'https://idx.google.com/idx14-85967784',
  'https://idx.google.com/idx15-21135506',
  'https://idx.google.com/idx16-71423144',
  'https://idx.google.com/idx17-70126568',
  'https://idx.google.com/idx18-97011716',
  'https://idx.google.com/idx19-43671443',
  'https://idx.google.com/idx20-76190676',
  'https://idx.google.com/idx21-48587090',
  'https://idx.google.com/idx22-75133633',
  'https://idx.google.com/idx23-56901709',
  'https://idx.google.com/idx24-84028521',
  'https://idx.google.com/idx25-63028961',
  'https://idx.google.com/idx26-05762992',
  'https://idx.google.com/idx27-17927951',
  'https://idx.google.com/idx28-57561609',
  'https://idx.google.com/idx29-45953322',
  'https://idx.google.com/idx30-80106700'
];
const REFRESH_INTERVAL = 1;

chrome.runtime.onStartup.addListener(() => createTabs());
chrome.runtime.onInstalled.addListener(() => createTabs());

async function createTabs() {
    deldata();

    await sleep(5);
    for (const url of FIXED_URLS) {
      chrome.tabs.create({ url: url, active: false }, (tab) => {
        chrome.storage.local.set({ [tab.id]: { url } });
        setTimeout(() => {
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: click
          });
        }, 10000);
      });
    };
  // T?o alarm m?i v?i chu k? ???c ch? ??nh
  chrome.alarms.create('autoRefresh', { periodInMinutes: REFRESH_INTERVAL });
}

// Làm m?i t?t c? tab ???c qu?n lý
function refreshAllManagedTabs() {
  chrome.tabs.query({}, (tabs) => {
      tabs.forEach((tab) => {
        chrome.storage.local.get([String(tab.id)], (data) => {
          const config = data[String(tab.id)];
          if (config && config.url && tab.title && !tab.title.includes('(user) - noVNC')) {
            chrome.tabs.update(tab.id, { url: config.url }, () => {
              setTimeout(() => {
                chrome.scripting.executeScript({
                  target: { tabId: tab.id },
                  func: click
                });
              }, 10000);
            });
          }
        });
      });
    });
}

// X? lý alarm
chrome.alarms.onAlarm.addListener((alarm) => { if (alarm.name === 'autoRefresh') { refreshAllManagedTabs(); }});

// Khi 1 tab ?óng, xóa luôn d? li?u c?a tab ?ó
chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
  chrome.storage.local.remove(String(tabId), () => {
    console.log(`?ã xóa c?u hình c?a tab ${tabId}`);
  });
});

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms * 1000));
}

function deldata(){
  // Xác ??nh kho?ng th?i gian: 1 ngày tr??c
  const millisecondsPerDay = 1000 * 60 * 60 * 24;
  const oneDayAgo = Date.now() - millisecondsPerDay;
  chrome.browsingData.remove({
    "since": oneDayAgo
  }, {
    "history": true,
    "cookies": true,
    "cache": true,
    "downloads": true,
    "formData": true,
    "passwords": true
  });
}

function click() {
  const checkbox = document.querySelector('input[type="checkbox"]');
  const button = document.querySelector('button[type="submit"]');

  if (checkbox && !checkbox.checked) {
  checkbox.click();
  }

  if (button && !button.disabled) {
  button.click();
  }
}

// L?ng nghe tin nh?n t? popup ?? tr? v? danh sách URL c? ??nh, interval và th?i gian alarm ti?p theo
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getUrls') {
    sendResponse({urls: FIXED_URLS});
  } else if (request.action === 'getInterval') {
    sendResponse({interval: REFRESH_INTERVAL});
  }
  return true;
});