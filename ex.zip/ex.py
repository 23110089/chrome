urls = [
    'https://idx.google.com/idx-00-66583824',
    'https://idx.google.com/idx02-35251293',
    'https://idx.google.com/idx03-14363638',
    'https://idx.google.com/idx04-15208805',
    'https://idx.google.com/idx05-86047270',
    'https://idx.google.com/idx06-95381027',
    'https://idx.google.com/vps07-20010284',
    'https://idx.google.com/idx09-22332842',
    'https://idx.google.com/idx10-19483612',
    'https://idx.google.com/idx11-47796700',
    'https://idx.google.com/idx12-73856221',
    'https://idx.google.com/idx13-69440052',
    'https://idx.google.com/idx14-85967784',
    'https://idx.google.com/idx15-21135506',
    'https://idx.google.com/idx16-71423144',
    'https://idx.google.com/idx17-70126568',
    'https://idx.google.com/idx18-97011716',
    'https://idx.google.com/idx19-43671443',
    'https://idx.google.com/idx20-76190676',
    'https://idx.google.com/idx21-48587090',
    'https://idx.google.com/idx22-75133633',
    'https://idx.google.com/idx23-56901709',
    'https://idx.google.com/idx24-84028521',
    'https://idx.google.com/idx25-63028961',
    'https://idx.google.com/idx26-05762992',
    'https://idx.google.com/idx27-17927951',
    'https://idx.google.com/idx28-57561609',
    'https://idx.google.com/idx29-45953322',
    'https://idx.google.com/idx30-80106700'
]

from psutil import process_iter
from os.path import exists, abspath
from shutil import copytree, rmtree
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from time import sleep
profile_dir = abspath('./').replace('\\', '/') + '/chrome'

def kill_process_using_path(path):
    path = path.lower().replace('\\', '/')  # Chuẩn hóa đường dẫn
    for proc in process_iter(['pid', 'name', 'cmdline']):
        try:
            cmdline = proc.info['cmdline']
            if cmdline:
                # Nối cmdline thành chuỗi và chuẩn hóa
                cmdline_str = ' '.join(cmdline).lower().replace('\\', '/')
                if path in cmdline_str:
                    proc.kill()
                    print(f"Đã tắt process {proc.info['name']} (PID: {proc.info['pid']}) sử dụng path: {path}")
        except: pass
    sleep(1)

def run():
    kill_process_using_path(profile_dir)
    if exists(profile_dir): rmtree(profile_dir)
    copytree(profile_dir+' - Copy', profile_dir)

    options = uc.ChromeOptions()
    options.add_argument(f"--user-data-dir=" + profile_dir)
    options.add_argument("--no-first-run --no-service-autorun --password-store=basic")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--lang=vi")
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-notifications")
    # ⚙️ Cấu hình chặn thông báo
    prefs = {
        "profile.default_content_setting_values.notifications": 2,       # chặn thông báo
        "profile.default_content_setting_values.clipboard": 2,           # chặn clipboard
        "profile.default_content_setting_values.popups": 2,              # chặn popups
        "profile.default_content_setting_values.translate": 2,           # Chặn gợi ý dịch trang
        "translate.enabled": False,                                      # Vô hiệu hóa hoàn toàn translate
        "profile.default_content_setting_values.automatic_downloads": 2, # chặn tải file tự động
    }
    options.add_experimental_option("prefs", prefs)

    driver = uc.Chrome(options=options, headless=False, use_subprocess=True)
    for url in urls:
        driver.execute_script(f"window.open('{url}', '_blank');")
        sleep(1)  # Đợi một chút để tránh quá tải
    driver.close()
    while True:
        dem = 0; reload = []
        tabs = driver.window_handles
        for tab in tabs:
            driver.switch_to.window(tab)
            title = driver.title
            if '(user) - noVNC' not in title:
                reload.append(tab); driver.refresh(); dem += 1
        sleep(10)
        for tab in reload:
            driver.switch_to.window(tab)
            checkbox = driver.find_elements(By.CSS_SELECTOR, 'input[type="checkbox"]')
            if checkbox and not checkbox[0].is_selected(): driver.execute_script("arguments[0].click();", checkbox[0])
            button = driver.find_elements(By.CSS_SELECTOR, 'button[type="submit"]')
            if button and button[0].is_enabled(): driver.execute_script("arguments[0].click();", button[0])
            sleep(1)
        sleep(60-dem if 60-dem > 5 else 5)

# begin
while True:
    try: run()
    except Exception as e:
        print(f"Error: {e}"); sleep(5)