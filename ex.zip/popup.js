document.addEventListener('DOMContentLoaded', function() {
    // Lấy danh sách URL từ background script
    chrome.runtime.sendMessage({action: 'getUrls'}, (response) => {
        if (response && response.urls) {
            displayUrls(response.urls);
        }
    });
    
    function displayUrls(urls) {
        const urlListDiv = document.querySelector('.url-list');
        if (urlListDiv) {
            let urlsHtml = '<strong>📋 Danh sách URLs:</strong>';
            urls.forEach(url => {
                urlsHtml += `<div class="url-item">• ${url}</div>`;
            });
            urlListDiv.innerHTML = urlsHtml;
        }
    }

    // Lấy interval từ background script
    chrome.runtime.sendMessage({action: 'getInterval'}, (response) => {
        if (response && response.interval) {
            updateIntervalText(response.interval);
        }
    });

    function updateIntervalText(interval) {
        const intervalText = document.getElementById('refresh-interval-text');
        if (intervalText) {
            intervalText.textContent = `🔄 Làm mới mỗi ${interval} phút`;
        }
    }
});
